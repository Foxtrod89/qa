package com.zubkov4victory;

import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.SerializationConfig;
import org.codehaus.jackson.map.ObjectMapper;

	@Provider
		public class ObjectMapperContextResolver implements ContextResolver<ObjectMapper> {
		private ObjectMapper mapper = null;
	    public ObjectMapperContextResolver() {super();
	       mapper = new ObjectMapper().configure(SerializationConfig.Feature.WRAP_ROOT_VALUE, true)
	                           .configure(DeserializationConfig.Feature.UNWRAP_ROOT_VALUE, true);}
	       @Override
	       public ObjectMapper getContext(Class<?> type) {return mapper;}
	}
