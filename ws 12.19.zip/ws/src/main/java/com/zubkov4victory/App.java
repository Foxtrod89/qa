package com.zubkov4victory;

import javax.ws.rs.GET;               // import javax.ws.rs.*;  
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.DELETE;
import javax.ws.rs.Consumes;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

@Path("/test")
public class App {
       
       @GET
       @Path("/{param}")          // http://localhost:8888/<war>/test?msg=This is a post verbs
       @Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
       public Response getMsg(@PathParam("param") String msg)            {
              String output = "Param [GET] : " + msg;
              return Response.status(200).entity(output).build();        }
       
       @POST
       @Path("/{param}")          // http://localhost:8888/<war>/test?msg=This is a post verbs
       @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
       @Produces({MediaType.APPLICATION_XML,MediaType.APPLICATION_JSON})
       public Response postMsg(@PathParam("param") String msg)           {
              String output = "Param [POST] : " + msg;
              return Response.status(201).entity(output).build();        }
       @PUT
       @Path("/{param}")         // http://localhost:8888/<war>/test?msg=This is a post verbs
       @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
       @Produces(MediaType.APPLICATION_XML)
       public Response putMsg(@PathParam("param") String msg)            {
              String output = "Param: [PUT] : " + msg;
              return Response.status(204).entity(output).build();        }
       @DELETE
       @Path("/{param}")        // http://localhost:8888/<war>/test?msg=This is a post verbs
       @Consumes({MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON})
       @Produces(MediaType.APPLICATION_XML)
       public Response deleteMsg(@PathParam("param") String msg)         {
              String output = "Param [DELETE] : " + msg;
              return Response.status(204).entity(output).build();        }
}
