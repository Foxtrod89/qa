package com.zubkov4victory;

import java.text.DecimalFormat;
import javax.ws.rs.*;
import javax.ws.rs.core.Response;
import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;


@Path("/")
public class JSONObjects {
    JSONObject json = new JSONObject();
    JSONObject json_array = new JSONObject();
    DecimalFormat df = new DecimalFormat("####0.00");

    @GET //#8
    @Path("json/kg=>lb")
    @Produces("application/json")
    public Response kg_to_lb_json(
            @DefaultValue("1")
            @QueryParam("input") Double input) throws JSONException {
        Double kg = input;
        Double lb = kg * 2.2046;
        String kg_out = df.format(kg).toString();
        String lb_out = df.format(lb).toString();
        json.put("calc", json_array);
        json_array.put("conversion", "kg to lb");
        json_array.put("kg", kg_out);
        json_array.put("lb", lb_out);
        String out = json.toString();
        return Response.status(200).entity(out).build();
    }
        @GET //#6
        @Path("json/lb=>kg")
        @Produces("application/json")
        public Response lb_to_kg_json(
                @DefaultValue("1")
                @QueryParam("input") Double input) throws JSONException {
            Double lb = input;
            Double kg = lb * 0.4536;
            String lb_out = df.format(lb).toString();
            String kg_out = df.format(kg).toString();
            json.put("calc", json_array);
            json_array.put("conversion", "lb to kg");
            json_array.put("lb", lb_out);
            json_array.put("kg", kg_out);
            String out = json.toString();
            return Response.status(200).entity(out).build();
    }
        @GET //#4
        @Path("json/cm=>in")
        @Produces("application/json")
        public Response cm_to_inch_json(
                @DefaultValue("1")
                @QueryParam("input") Double input) throws JSONException {
            Double cm = input;
            Double inches = cm * 0.3937;
            String cm_out = df.format(cm).toString();
            String inches_out = df.format(inches).toString();
            json.put("calc", json_array);
            json_array.put("conversion", "cm to inches");
            json_array.put("cm", cm_out);
            json_array.put("inches", inches_out);
            String out = json.toString();
            return Response.status(200).entity(out).build();
    }
        @GET //#2
        @Path("json/in=>cm")
        @Produces("application/json")
        public Response inches_to_cm_json(
                @DefaultValue("1")
                @QueryParam("input") Double input) throws JSONException {
            Double inches = input;
            Double cm = inches * 2.54;
            String in_out = df.format(inches).toString();
            String cm_out = df.format(cm).toString();
            json.put("calc", json_array);
            json_array.put("conversion", "inches to cm");
            json_array.put("inches", in_out);
            json_array.put("cm", cm_out);
            String out = json.toString();
            return Response.status(200).entity(out).build();
    }
}