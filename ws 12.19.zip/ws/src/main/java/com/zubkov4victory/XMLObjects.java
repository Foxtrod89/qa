package com.zubkov4victory;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class XMLObjects {
       public static void main(String argv[]) throws ParserConfigurationException, TransformerException{
              DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
              DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
              // root elements
              Document doc = docBuilder.newDocument();
              Element rootElement = doc.createElement("calc");
              rootElement.setAttribute("conversion", " kg to lb");
              doc.appendChild(rootElement);
              // first element
              Element first = doc.createElement("kg");
              first.appendChild(doc.createTextNode("100.00"));
              rootElement.appendChild(first);
              // second element
              Element second = doc.createElement("lb");
              second.appendChild(doc.createTextNode("220.46"));
              rootElement.appendChild(second);
              // write the content into xml file
              TransformerFactory transformerFactory = TransformerFactory.newInstance();
              Transformer transformer = transformerFactory.newTransformer();
              DOMSource source = new DOMSource(doc);
              StreamResult result = new StreamResult(new File("output_zubkov.xml"));
              transformer.transform(source, result);}
}

