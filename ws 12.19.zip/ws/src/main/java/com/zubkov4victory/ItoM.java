package com.zubkov4victory;

  import java.text.DecimalFormat;
  import javax.ws.rs.DefaultValue;
  import javax.ws.rs.GET;
  import javax.ws.rs.Path;
  //import javax.ws.rs.PathParam;
  import javax.ws.rs.Produces;
  import javax.ws.rs.QueryParam;
  import javax.ws.rs.core.MediaType;

       @Path("/converter")
       
       public class ItoM {
               
         @GET
         @Path("/xml")
         @Produces(MediaType.APPLICATION_XML)
         public String CalcItoCmxml(
                @DefaultValue("1") @QueryParam("IntoCm") int h)  
                {
              DecimalFormat df1 = new DecimalFormat("####0.0");
                Double intocm = (double) h * 2.54;            
                String result1 = df1.format(intocm).toString();
                return "<calc conversion=\"inches to centimeter\">" + "<inches>" + h + "</inches>" + "<centimeter>" + result1 + "</centimeter>" + "</calc>";}
         @GET
         		@Path("/json")
         		@Produces(MediaType.APPLICATION_JSON)
         		public String CalcItoCjson(
         		@DefaultValue("1") @QueryParam("IntoCm") int h)       
               {
                DecimalFormat df2 = new DecimalFormat("####0.0");
                Double intocm = (double) h * 2.54;            
                String result2 = df2.format(intocm).toString();
                return "{\"calc\": \n\t{\n\t\"conversion\": \"inches to centimeters\", \n\t\"inches\":\t" + h + "," + "\n\t\"centimeter\": " + result2 + "\n\t}\n}";}
         
         @GET
              @Path("/xml2")
              @Produces(MediaType.APPLICATION_XML)
              public String CalcCtoIxml(
                     @DefaultValue("1") @QueryParam("CmtoIn") int g)  
                     {
                   DecimalFormat df3 = new DecimalFormat("####0.0");
                     Double cmtoin = (double) g * 0.3937;            
                     String result3 = df3.format(cmtoin).toString();
                     return "<calc conversion=\"centimeters to inches\">" + "<centimeter>" + g + "</centimeter>" + "<inches>" + result3 + "</inches>" + "</calc>";}
         @GET
              @Path("/json2")
              @Produces(MediaType.APPLICATION_JSON)
              public String CalcCtoIjson(
                 @DefaultValue("1") @QueryParam("CmtoIn") int g)       
                    {
                     DecimalFormat df = new DecimalFormat("####0.0");
                     Double cmtoin = (double) g * 0.3937;            
                     String result4 = df.format(cmtoin).toString();
                     return "{\"calc\": \n\t{\n\t\"conversion\": \"centimeters to inches\", \n\t\"centimeter\":\t" + g + "," + "\n\t\"inches\": " + result4 + "\n\t}\n}";
                    }
         
         @GET
                     @Path("/xml3")
                     @Produces(MediaType.APPLICATION_XML)
                     public String CalcPtoKmxml(
                            @DefaultValue("1") @QueryParam("LbtoKg") int lb)  
                            {
                          DecimalFormat df5 = new DecimalFormat("####0.0");
                            Double kg = (double) lb * 0.4536;            
                            String result5 = df5.format(kg).toString();
                            return "<calc conversion=\"pounds to kilograms\">" + "<pound>" + lb + "</pound>" + "<kilograms>" + result5 + "</kilograms>" + "</calc>";           
                     }
         
         @GET
         		@Path("/json3")
         		@Produces(MediaType.APPLICATION_JSON)
         		public String CalcPtoKmjson(
                @DefaultValue("1") @QueryParam("LbtoKg") int lb)  
                {
                DecimalFormat df6 = new DecimalFormat("####0.0");
                Double kg = (double) lb * 0.4536;            
                String result6 = df6.format(kg).toString();
                return "{\"calc\": \n\t{\n\t\"conversion\": \"pounds to kilograms\", \n\t\"pound\":    " + lb + "," + "\n\t\"kilogram\": " + result6 + "\n\t}\n}";
                }
         @GET
         @Path("/xml4")
         @Produces(MediaType.APPLICATION_XML)
         public String CalcKtoPmxml(
                @DefaultValue("1") @QueryParam("KgtoLb") int kg)  
                {
              DecimalFormat df7 = new DecimalFormat("####0.0");
                Double lb = (double) kg * 2.2046;            
                String result7 = df7.format(lb).toString();
                return "<calc conversion=\"kilograms to pounds\">" + "<kilogram>" + kg + "</kilogram>" + "<pound>" + result7 + "</pound>" + "</calc>";           
                }
         
         @GET
         @Path("/json4")
         @Produces(MediaType.APPLICATION_JSON)
         public String CalcKtoPmjson(
                @DefaultValue("1") @QueryParam("KgtoLb") int kg)  
                {
              DecimalFormat df8 = new DecimalFormat("####0.0");
                Double lb = (double) kg * 2.2046;            
                String result8 = df8.format(lb).toString();
                return "{\"calc\": \n\t{\n\t\"conversion\": \"kilograms to pounds\", \n\t\"kilogram\":\t  " + kg + "," + "\n\t\"pound\":\t" + result8 + "\n\t}\n}";
                }
         }
               
    
